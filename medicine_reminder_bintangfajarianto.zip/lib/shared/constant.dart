// Bintang Fajarianto
// Submission Dicoding : Belajar Membuat Aplikasi Flutter untuk Pemula

import 'package:flutter/material.dart';

const Color homeBg = Color(0xFFf6f6f6);
const Color cardBg = Color(0xFFf9feff);
const Color tPrimaryWhite = Color(0xFFFFFDFF);
const Color tPrimaryGrey = Color(0xFFececec);
const Color tPrimaryOrange = Color(0xFFffba5d);
const Color tPrimaryBlue = Color(0xFF20304f);
const Color tPrimaryBlack = Color(0xFF404447);
const Color tPrimaryBlack30 = Color(0x4C404447);
const Color tBrown1Color = Color(0xFFc89e85);
const Color tBrown2Color = Color(0xFFca7e58);
const Color tBrown3Color = Color(0xFFf6f0ed);
