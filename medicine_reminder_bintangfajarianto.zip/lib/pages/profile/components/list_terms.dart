// Bintang Fajarianto
// Submission Dicoding : Belajar Membuat Aplikasi Flutter untuk Pemula

import 'package:flutter/material.dart';

class ListTerms {
  final String title;
  final Icon icon;
  final void Function() onTap;
  ListTerms({required this.title, required this.icon, required this.onTap});
}
